#ifndef VECTOR_CALCULUS_H
#define VECTOR_CALCULUS_H

#include <iostream>
#include <cmath>

class Vector3D {
private:
    double x, y, z;

public:

    // -------- Function Overloading --------

    Vector3D() : x(0), y(0), z(0) {}

    Vector3D(double a, double b, double c) : x(a), y(b), z(c) {}

    Vector3D(const Vector3D &v) : x(v.x), y(v.y), z(v.z) {}

    void setValues() {
        x = y = z = 0;
    }

    void setValues(double a, double b, double c) {
        x = a;
        y = b;
        z = c;
    }

    void setValues(const Vector3D &v) {
        x = v.x;
        y = v.y;
        z = v.z;
    }

    // -------- Operator Overloading --------

    Vector3D operator+(const Vector3D &v) const {
        return Vector3D(x + v.x, y + v.y, z + v.z);
    }

    Vector3D operator-(const Vector3D &v) const {
        return Vector3D(x - v.x, y - v.y, z - v.z);
    }

    double operator*(const Vector3D &v) const {
        return (x * v.x + y * v.y + z * v.z);
    }

    bool operator==(const Vector3D &v) const {
        return (x == v.x && y == v.y && z == v.z);
    }

    bool operator<(const Vector3D &v) const {
        return magnitude() < v.magnitude();
    }

    // -------- Extra Function --------
    double magnitude() const {
        return std::sqrt(x * x + y * y + z * z);
    }

    // -------- Output Operator --------
    friend std::ostream& operator<<(std::ostream &out, const Vector3D &v) {
        out << "(" << v.x << ", " << v.y << ", " << v.z << ")";
        return out;
    }
};

#endif